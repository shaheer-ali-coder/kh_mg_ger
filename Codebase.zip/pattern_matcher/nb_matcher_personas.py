from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline

# WORK IN PROGRESS

expressions = [
    ("a)", "Performance-Related"),
    ("b)", "Workload Management"),
    ("c)", "Social and Psychological"),
    ("d)", "Career and Future"),
    ("e)", "Environmental and Personal Well-being"),
    ("a", "Performance-Related"),
    ("b", "Workload Management"),
    ("c", "Social and Psychological"),
    ("d", "Career and Future"),
    ("e", "Environmental and Personal Well-being"),
    ("Performance-Related Stress", "Performance-Related"),
    ("Workload Management Stress", "Workload Management"),
    ("Social and Psychological Stress (FOMO, imposter, peer pressure)", "Social and Psychological"),
    ("Career and Future Anxiety", "Career and Future"),
    ("Environmental and Personal Well-being Stress (financial, burnout, tech stress)", "Environmental and Personal Well-being")
]


class PatternMatcher_Personas:
    def __init__(self):
        X, y = zip(*expressions)
        model = make_pipeline(CountVectorizer(), MultinomialNB())
        model.fit(X, y)

        self.model = model
        self.responses = expressions

    def get_category(self, user_input):
        predicted_category = self.model.predict([user_input])[0]
        return predicted_category

