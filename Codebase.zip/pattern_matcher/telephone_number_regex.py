import os
from dotenv import load_dotenv

load_dotenv()
PATH_PERMITTED_COUNTRY_CODES = os.getenv('PATH_PERMITTED_COUNTRY_CODES')
PATH_PERMITTED_TELEPHONE_NUMBERS = os.getenv('PATH_PERMITTED_TELEPHONE_NUMBERS')


class telephone_number_regex:
    def __init__(self):
        with open(PATH_PERMITTED_COUNTRY_CODES, 'r') as file:
            patterns = {line.strip() for line in file.readlines()}
        self.country_codes = patterns

        with open(PATH_PERMITTED_TELEPHONE_NUMBERS, 'r') as file:
            patterns = {line.strip() for line in file.readlines()}
        self.telephone_numbers = patterns

    def check_for_country_code(self, telephone_number):
        for pattern in self.country_codes:
            if telephone_number.startswith(pattern):
                return True
        return False

    def check_for_telephone_number(self, telephone_number):
        for pattern in self.telephone_numbers:
            if telephone_number.startswith(pattern):
                return True
        return False
