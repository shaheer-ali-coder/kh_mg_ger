from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline

expressions = [
    ("yes", True),
    ("yo", True),
    ("aye", True),
    ("sure", True),
    ("no", False),
    ("nope", False),
    ("nah", False),
    ("ney", False)
]


class PatternMatcher_Boolean:
    def __init__(self):
        X, y = zip(*expressions)
        model = make_pipeline(CountVectorizer(), MultinomialNB())
        model.fit(X, y)

        self.model = model
        self.responses = expressions

    def get_boolean(self, user_input):
        predicted_category = self.model.predict([user_input])[0]
        if predicted_category:
            return True
        else:
            return False

