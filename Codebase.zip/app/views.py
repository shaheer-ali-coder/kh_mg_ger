import json
import logging
from flask import Blueprint, request, jsonify
from .decorators.security import signature_required
from .utils.whatsapp_utils import process_whatsapp_message, is_valid_whatsapp_message
from .webhook_verification import verify

webhook_blueprint = Blueprint("webhook", __name__)


# Verarbeitung einer eingegangenen Nachricht über den Webhook
def handle_message():
    body = request.get_json()

    # Prüfung, ob es ein WhatsApp Statusupdate ist
    if body.get("entry", [{}])[0].get("changes", [{}])[0].get("value", {}).get("statuses"):
        # logging.info("Received a WhatsApp status update.")
        return jsonify({"status": "ok"}), 200

    try:
        if is_valid_whatsapp_message(body):
            process_whatsapp_message(body)
            return jsonify({"status": "ok"}), 200
        else:
            # Fehlerausgabe, wenn das Schema kein Statusupdate ist
            return (
                jsonify({"status": "error", "message": "Not a WhatsApp API event"}),
                404,
            )
    # Genereller Fehler, wenn JSON nicht dekodiert werden kann
    except json.JSONDecodeError:
        logging.error("Failed to decode JSON")
        return jsonify({"status": "error", "message": "Invalid JSON provided"}), 400


# Route zur META Webhook verifikation
@webhook_blueprint.route("/webhook", methods=["GET"])
def webhook_get():
    return verify()


# Route zum regulären Webhook
@webhook_blueprint.route("/webhook", methods=["POST"])
@signature_required
def webhook_post():
    return handle_message()
