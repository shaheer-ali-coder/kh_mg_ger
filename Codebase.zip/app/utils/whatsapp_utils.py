import logging
import json
import nlp_handler
import re
import requests
import time
from app.services.openai_service import generate_response
from config import sessions, onboarding_sessions, telephone_number_regex
from database_handler import get_user_data
from flask import current_app, jsonify

MAX_POST_RETRIES = 10


# HTTP Logging
def log_http_response(response):
    logging.info(f"Status: {response.status_code}")
    logging.info(f"Content-type: {response.headers.get('content-type')}")
    logging.info(f"Body: {response.text}")


# Payload zum Versenden vorbereiten
def parse_payload_for_whatsapp(recipient, text):
    return json.dumps(
        {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": recipient,
            "type": "text",
            "text": {"preview_url": False, "body": text},
        }
    )


def parse_template_for_whatsapp(recipient):
    return json.dumps({"messaging_product": "whatsapp",
                       "recipient_type": "individual",
                       "to": recipient,
                       "template": {
                           "name": "academic_stress_selection_v1",
                           "language": {
                               "code": "en_US"
                           }}})


def send_message(payload):
    headers = {
        "Content-type": "application/json",
        "Authorization": f"Bearer {current_app.config['ACCESS_TOKEN']}",
    }

    # Pfad zur POST Methode / META WhatsApp API
    url = f"https://graph.facebook.com/{current_app.config['VERSION']}/{current_app.config['PHONE_NUMBER_ID']}/messages"

    attempts = 0

    while attempts < MAX_POST_RETRIES:
        try:
            response = requests.post(
                url, data=payload, headers=headers, timeout=10
            )

            response.raise_for_status()  # If there's an HTTP error, it will raise an HTTPError
            logging.info("Message successfully sent")
            break  # If the request is successful, exit the loop
        except requests.Timeout:
            logging.error("Timeout occurred while sending message")
            return jsonify({"status": "error", "message": "Request timed out"}), 408
        except requests.RequestException as e:
            logging.error(f"Request failed due to: {e}")
            attempts += 1
            if attempts >= MAX_POST_RETRIES:
                return jsonify({"status": "error", "message": "Failed to send message"}), 500
            time.sleep(1)  # Wait for 1 second before retrying


def process_text_for_whatsapp(text):
    # Eckige Klammern entfernen
    text = re.sub(r"\【.*?\】", "", text).strip()

    # Sterne und Fragezeichen entfernen
    whatsapp_style_text = re.sub(r"\*\*(.*?)\*\*", r"*\1*", text)

    return whatsapp_style_text


def get_whatsapp_message(body):
    message = body["entry"][0]["changes"][0]["value"]["messages"][0]
    message_body = message["text"]["body"]

    return message_body


def check_if_message_is_expired(timestamp):
    if (time.time() - timestamp) >= 300:
        return True
    else:
        return False


def process_whatsapp_message(body):
    telephone_number = body["entry"][0]["changes"][0]["value"]["contacts"][0]["wa_id"]
    try:
        message = get_whatsapp_message(body)
    except Exception as e:
        logging.error(e)
        return

    if check_if_message_is_expired(int(body["entry"][0]["changes"][0]["value"]["messages"][0]["timestamp"])):
        return

    # Prüfen, ob die Ländervorwahl oder Rufnummer für die Nutzung von HoldMe freigegeben sind
    """if not telephone_number_regex.check_for_country_code(telephone_number):
        if not telephone_number_regex.check_for_telephone_number(telephone_number):
            return"""

    # Solange das Development läuft
    if not telephone_number_regex.check_for_telephone_number(telephone_number):
        return

    send_message(parse_template_for_whatsapp(telephone_number))
    return

    # Prüfen ob Sitzung bereits besteht
    if sessions.check_if_session_exists(telephone_number):
        # Prüfen ob Response bereits erwartet wird
        if sessions.check_if_response_is_awaited(telephone_number):
            return

        sessions.set_awaiting_response(telephone_number, True)

        nlp_handler.perform_analysis(sessions.get_user_id(telephone_number), message,
                                     sessions.get_conversation_id(telephone_number))
        response = generate_response(message, telephone_number, sessions.get_name(telephone_number))
        sessions.set_awaiting_response(telephone_number, False)
        response = process_text_for_whatsapp(response)

        send_message(parse_payload_for_whatsapp(telephone_number, response))
        return

    if onboarding_sessions.check_if_session_exists(telephone_number):
        if onboarding_sessions.check_if_onboarding_is_completed(telephone_number):
            response = onboarding_sessions.perform_whodas_assessment(telephone_number, message)
            for i in response:
                send_message(parse_payload_for_whatsapp(telephone_number, i))

        else:
            response = onboarding_sessions.perform_onboarding_questions(telephone_number, message)
            for i in response:
                send_message(parse_payload_for_whatsapp(telephone_number, i))

    else:
        # Prüfen ob User in der Datenbank bekannt ist
        query_user_data = get_user_data(telephone_number)
        if query_user_data:
            if not query_user_data.whodas_assessment_complete:
                onboarding_sessions.new_session(telephone_number, user_assessment_state=True)
                response = onboarding_sessions.perform_whodas_assessment(telephone_number)
                for i in response:
                    send_message(parse_payload_for_whatsapp(telephone_number, i))

            else:
                sessions.new_session(telephone_number, query_user_data.name, query_user_data.user_id)

                response = generate_response(message, telephone_number, query_user_data.name)
                response = process_text_for_whatsapp(response)

                send_message(parse_payload_for_whatsapp(telephone_number, response))
                return

        else:
            onboarding_sessions.new_session(telephone_number)
            response = onboarding_sessions.perform_onboarding_questions(telephone_number, message)
            for i in response:
                send_message(parse_payload_for_whatsapp(telephone_number, i))


# Prüfung, ob empfangene Payload eine WhatsApp Nachricht ist
def is_valid_whatsapp_message(body):
    return (
            body.get("object")
            and body.get("entry")
            and body["entry"][0].get("changes")
            and body["entry"][0]["changes"][0].get("value")
            and body["entry"][0]["changes"][0]["value"].get("messages")
            and body["entry"][0]["changes"][0]["value"]["messages"][0]
    )
