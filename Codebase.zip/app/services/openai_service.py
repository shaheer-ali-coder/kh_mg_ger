import logging
import os
import time
from config import sessions
from dotenv import load_dotenv
from openai import OpenAI


load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_ASSISTANT_ID = os.getenv("OPENAI_ASSISTANT_ID")  # AKA die Vorlage des Assistenten
client = OpenAI(api_key=OPENAI_API_KEY)


def run_assistant(thread, name):
    # Abruf des Assistenten für einen neuen Thread
    assistant = client.beta.assistants.retrieve(OPENAI_ASSISTANT_ID)

    # Neuen Run erstellen
    run = client.beta.threads.runs.create(
        thread_id=thread.id,
        assistant_id=assistant.id,
        instructions=f"You are having a conversation with {name}",
    )

    # Prüfe alle 0,5 Sekunden auf vollständige Response des Bots
    # https://platform.openai.com/docs/assistants/how-it-works/runs-and-run-steps#:~:text=under%20failed_at.-,Polling%20for%20updates,-In%20order%20to
    while run.status != "completed":
        time.sleep(0.5)
        run = client.beta.threads.runs.retrieve(thread_id=thread.id, run_id=run.id)

    # Retrieve the Messages
    messages = client.beta.threads.messages.list(thread_id=thread.id)
    new_message = messages.data[0].content[0].text.value
    return new_message


# Nachricht an den Assistant pushen
def generate_response(message_payload, telephone_number, name):
    # Wenn noch kein Thread existiert, lege einen neuen an
    if not sessions.get_thread_data(telephone_number):
        logging.info(f"Neuer Thread für {telephone_number}")
        sessions.set_thread_data(telephone_number, client.beta.threads.create())

    # Nachricht an den Thread anfügen
    client.beta.threads.messages.create(
        thread_id=sessions.get_thread_data(telephone_number).id,
        role="user",
        content=message_payload
    )

    # Assistant Run
    new_message = run_assistant(sessions.get_thread_data(telephone_number), name)

    return new_message
