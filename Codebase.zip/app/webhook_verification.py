import logging
from flask import request, current_app, jsonify


# Verifikation des Webhooks über Meta
def verify():
    # Parameter parsing
    mode = request.args.get("hub.mode")
    token = request.args.get("hub.verify_token")
    challenge = request.args.get("hub.challenge")

    # Qualifizierung 1
    if mode and token:
        # Qualifizierung 2
        if mode == "subscribe" and token == current_app.config["VERIFY_TOKEN"]:
            # Bei Erfolg
            logging.info("WEBHOOK_VERIFIED")
            return challenge, 200

        else:
            # Fehler ausgeben, wenn Tokens nicht identisch sind
            logging.info("VERIFICATION_FAILED")
            return jsonify({"status": "error", "message": "Verification failed"}), 403

    else:
        # Genereller Fehler, wenn falsche oder keine Parameter übermittelt worden sind
        logging.info("MISSING_PARAMETER")
        return jsonify({"status": "error", "message": "Missing parameters"}), 400

