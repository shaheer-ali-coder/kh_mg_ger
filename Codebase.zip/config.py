from empath import Empath
from pattern_matcher import telephone_number_regex
from stores import session_store, onboarding_sessions_store

sessions = session_store.Session()
onboarding_sessions = onboarding_sessions_store.Session()
telephone_number_regex = telephone_number_regex.telephone_number_regex()
lexicon = Empath()

