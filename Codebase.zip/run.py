import logging
import ssl
from app import create_app

# Einbindung der SSL Zertifikate
context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
context.load_cert_chain("keys/fullchain.pem", "keys/privkey.pem")

# Started den Broker
app = create_app()

if __name__ == "__main__":
    logging.info("Flask app started")
    app.run(host="0.0.0.0", port=50000, ssl_context=context)

