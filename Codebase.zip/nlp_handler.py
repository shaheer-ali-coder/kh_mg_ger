from config import lexicon
from database_handler import store_new_message


def perform_analysis(user_id, text, conversation_id):
    analyze = lexicon.analyze(text, normalize=True)
    store_new_message(user_id, conversation_id, len(text.split()), **analyze)
