import uuid
from datetime import datetime


class Session:
    def __init__(self):
        self.sessions = dict(dict())

    def new_session(self, telephone_number, name, user_id):
        self.sessions[telephone_number] = {
            "name": name,
            "user_id": user_id,
            "thread_data": None,
            "awaiting_response": False,
            "last_message_time": datetime.now().isoformat(),
            "conversation_id": str(uuid.uuid4())
        }

    def check_if_response_is_awaited(self, telephone_number):
        return self.sessions[telephone_number]["awaiting_response"]

    def check_if_session_exists(self, telephone_number):
        if telephone_number in self.sessions:
            return True
        else:
            return False

    def get_conversation_id(self, telephone_number):
        return self.sessions[telephone_number]["conversation_id"]

    def get_last_message_time(self, telephone_number):
        return self.sessions[telephone_number]["last_message_time"]

    def get_name(self, telephone_number):
        name = self.sessions[telephone_number]["name"]
        return name

    def get_thread_data(self, telephone_number):
        if not self.sessions[telephone_number]["thread_data"]:
            return None
        return self.sessions[telephone_number]["thread_data"]

    def get_user_id(self, telephone_number):
        return self.sessions[telephone_number]["user_id"]

    def update_last_message(self, telephone_number):
        self.sessions[telephone_number]["last_message_time"] = datetime.now().isoformat()

    def set_awaiting_response(self, telephone_number, status):
        self.sessions[telephone_number]["awaiting_response"] = bool(status)

    def set_thread_data(self, telephone_number, thread):
        self.sessions[telephone_number]["thread_data"] = thread

    def delete_session(self, telephone_number):
        del self.sessions[telephone_number]

