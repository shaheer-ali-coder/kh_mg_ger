from database_handler import create_new_whodas_assessment, create_new_user, get_user_data, set_whodas_assessment_complete
from datetime import datetime
from pattern_matcher.nb_matcher_boolean import PatternMatcher_Boolean
from pattern_matcher.nb_matcher_personas import PatternMatcher_Personas
from pattern_matcher.nb_matcher_stress_type import PatternMatcher_Stress_Type
from pattern_matcher.nb_matcher_whodas import PatternMatcher_Whodas


def convert_to_integer(user_input) -> int:
    try:
        return int(user_input)
    except ValueError:
        return -1


class Session:
    def __init__(self):
        self.sessions = dict(dict())
        self.onboarding_responses = dict()
        self.assessment_responses = dict()
        self.nb_boolean_matcher = PatternMatcher_Boolean()
        self.nb_matcher_whodas = PatternMatcher_Whodas()
        self.nb_matcher_personas = PatternMatcher_Personas()
        self.nb_matcher_stress_type = PatternMatcher_Stress_Type()

    def debug_session(self, telephone_number):
        print(
            self.sessions[telephone_number],
            "LAST MESSAGE:", self.sessions[telephone_number]["last_message_time"],
            "USER ASSESSMENT STEP:", self.sessions[telephone_number]["user_assessment_step"],
            "USER ASSESSMENT COMPLETE:", self.sessions[telephone_number]["user_assessment_complete"],
            "WHODAS ASSESSMENT STEP:", self.sessions[telephone_number]["whodas_assessment_step"]
        )

    def new_session(self, telephone_number, user_assessment_state=False):
        self.sessions[telephone_number] = {
            "last_message_time": datetime.now().isoformat(),
            "user_assessment_step": 0,
            "user_assessment_complete": user_assessment_state,
            "whodas_assessment_step": 0
        }

    def check_if_session_exists(self, telephone_number):
        if telephone_number in self.sessions:
            return True
        else:
            return False

    def check_if_onboarding_is_completed(self, telephone_number):
        return self.sessions[telephone_number]["user_assessment_complete"]

    def update_last_message_time(self, telephone_number):
        self.sessions[telephone_number]["last_message_time"] = datetime.now().isoformat()

    def update_user_assessment_step(self, telephone_number, step_value):
        self.sessions[telephone_number]["user_assessment_step"] = self.sessions[telephone_number][
                                                                      "user_assessment_step"] + step_value

    def update_whodas_assessment_step(self, telephone_number, step_value):
        self.sessions[telephone_number]["whodas_assessment_step"] = self.sessions[telephone_number][
                                                                        "whodas_assessment_step"] + step_value

    def delete_session(self, telephone_number):
        del self.sessions[telephone_number]

    def perform_onboarding_questions(self, telephone_number, user_input=None):
        self.update_last_message_time(telephone_number)
        self.update_user_assessment_step(telephone_number, 1)
        match self.sessions[telephone_number]["user_assessment_step"]:
            case 1:
                return [
                    "Hey there! Welcome to LeanOnMe! 🎓 I’m Leany, your AI buddy here to help you crush academic stress 24/7 and feel awesome. Let’s get to know each other.🙂",
                    "How should I call you? 🙂"]

            case 2:
                self.onboarding_responses["name"] = user_input
                return [
                    f"Nice to meet you, {user_input}! 😊",
                    "How old are you? Please note that we are available for 18 - 25 year old only at the moment",
                ]

            case 3:
                user_input = convert_to_integer(user_input)
                if not user_input >= 0:
                    self.delete_session(telephone_number)
                    return [
                        "Apologies, we're unable to assist you at this time. Don't worry though, you can reserve your spot on our waitlist until we're able to help. 😊 https://leanonme.ai/waitlist/"
                    ]

                self.onboarding_responses["age"] = user_input
                return [
                    f"Thanks for sharing, {self.onboarding_responses['name']}",
                    "For safety and compliance reasons, could you please confirm the country where you currently live?",
                ]

            case 4:
                self.onboarding_responses["country"] = user_input
                return [
                    "Alright, thanks! 🌍",
                    "Just so you know, LeanOnMe is currently in a testing phase, focusing exclusively on Academic Stress. Do you agree to proceed under this condition?",
                ]

            case 5:
                user_input = self.nb_boolean_matcher.get_boolean(user_input)
                if not user_input:
                    self.delete_session(telephone_number)
                    return [
                        "No worries. Let's put your name down on our waitlist until more topics are available that suit your needs. 😊 https://leanonme.ai/waitlist/"
                    ]

                self.onboarding_responses["testing_consent"] = user_input
                return [
                    "Great, let's continue.",
                    "Are you currently in a safe space? Do you feel physically safe at the moment?",
                ]

            case 6:
                user_input = self.nb_boolean_matcher.get_boolean(user_input)
                if not user_input:
                    self.delete_session(telephone_number)
                    return [
                        "Your safety is our priority. Please visit our professional crisis page for immediate support https://leanonme.ai/crisis/"
                    ]

                self.onboarding_responses["is_safe"] = user_input
                return [
                    f"Glad to hear that you're in a safe space, {self.onboarding_responses['name']}. That's a good baseline to start this journey with you 🛡️",
                    "Which persona best represents your academic stress type? Please select one:\n"
                    "Overachiever - High expectations, perfectionism, fear of failure.\n"
                    "Procrastinator - Struggles with time management and delays studying.\n"
                    "Adjustment Struggler - Facing difficulties adjusting to new environments.\n"
                    "External Acute Crisis Victim - External life events causing significant stress.\n"
                    "Psychosomatic - Physical illness exacerbated by or causing stress.\n"
                    "Chronic Illness - Managing chronic health issues alongside academic workload.'"
                ]

            case 7:
                self.onboarding_responses["stress_persona"] = self.nb_matcher_personas.get_category(user_input)
                return [
                    "Thanks, that's helpful.",
                    "Which academic stress type are you struggling the most with at the moment?\n"
                    "a) Performance\n"
                    "b) Workload\n"
                    "c) FOMO, imposter, peer pressure\n"
                    "d) Career and Future\n"
                    "e) Well-being: financial, burnout, tech stress"
                ]

            case 8:
                self.onboarding_responses["stress_focus"] = self.nb_matcher_stress_type.get_category(user_input)
                return ["Got it.",
                        "Before we proceed, please review and accept our Terms and Conditions to continue using our services. All your data is confidential and transparent. You can read all about it here: https://leanonme.ai/termsandconditions/"]

            case _:
                user_input = self.nb_boolean_matcher.get_boolean(user_input)
                if not user_input:
                    self.delete_session(telephone_number)
                    return [
                        "Ok that's cool. Would you mind telling us why you declined? Talk to us https://leanonme.ai/contact/. Thanks. Stay healthy! Take care."]

                self.onboarding_responses["terms_of_service_consent"] = user_input
                self.sessions[telephone_number]["user_assessment_complete"] = True
                create_new_user(telephone_number, **self.onboarding_responses)
                return [
                    "Thanks! Your data is safe with us 🔒",
                    "We're almost there! To help us provide the best support, we need to understand a bit more about how stress affects your daily life. We'll start with a brief assessment (WHODAS). This assessment helps us tailor our support to your specific needs and track your progress over time. It is essential for us to provide the best service possible. We will run the WHODAS12 at the beginning and end of the POC phase.",
                    "So this assessment always refers to 'In the past 30 days, how much difficulty did you have in...' e.g. standing for long periods such as 30 minutes? and you will have several answer options. So let's start:",
                    "Have you trouble with Standing for long periods such as 30 minutes?\n\n(None, Mild, Moderate, Severe, Extreme or cannot do)"
                ]

    def perform_whodas_assessment(self, telephone_number, user_input=None):
        self.update_last_message_time(telephone_number)
        self.update_whodas_assessment_step(telephone_number, 1)
        match self.sessions[telephone_number]["whodas_assessment_step"]:
            case 1:
                if not user_input:
                    self.update_whodas_assessment_step(telephone_number, -1)
                    return [
                        "We're almost there! To help us provide the best support, we need to understand a bit more about how stress affects your daily life. We'll start with a brief assessment (WHODAS). This assessment helps us tailor our support to your specific needs and track your progress over time. It is essential for us to provide the best service possible. We will run the WHODAS12 at the beginning and end of the POC phase.",
                        "So this assessment always refers to 'In the past 30 days, how much difficulty did you have in...' e.g. standing for long periods such as 30 minutes? and you will have several answer options. So let's start:",
                        "Have you trouble with Standing for long periods such as 30 minutes?\n\n(None, Mild, Moderate, Severe, Extreme or cannot do)"
                    ]
                self.assessment_responses["s1"] = self.nb_matcher_whodas.get_category(user_input)
                return [
                    "Have you trouble with Taking care of your household responsibilities?\n\n(None, Mild, "
                    "Moderate, Severe, Extreme or cannot do)"
                ]

            case 2:
                self.assessment_responses["s2"] = self.nb_matcher_whodas.get_category(user_input)
                return [
                    "Have you trouble with Learning a new task, for example, learning how to get to a new place?"
                    "\n\n(None, Mild, Moderate, Severe, Extreme or cannot do)"
                ]

            case 3:
                self.assessment_responses["s3"] = self.nb_matcher_whodas.get_category(user_input)
                return [
                    "Have you trouble with How much of a problem did you have joining in community activities "
                    "(for example, festivities, religious or other activities) in the same way as anyone else can?"
                    "\n\n(None, Mild, Moderate, Severe, Extreme or cannot do)"
                ]

            case 4:
                self.assessment_responses["s4"] = self.nb_matcher_whodas.get_category(user_input)
                return [
                    "Have you trouble with How much have you been emotionally affected by your health problems?\n\n(None, Mild, Moderate, Severe, Extreme or cannot do)"
                ]

            case 5:
                self.assessment_responses["s5"] = self.nb_matcher_whodas.get_category(user_input)
                return [
                    "Have you trouble with Concentrating on doing something for ten minutes?\n\n(None, Mild, Moderate, Severe, Extreme or cannot do)"]

            case 6:
                self.assessment_responses["s6"] = self.nb_matcher_whodas.get_category(user_input)
                return [
                    "Have you trouble with Walking a long distance such as a kilometre (or equivalent)?\n\n(None, Mild, Moderate, Severe, Extreme or cannot do)"]

            case 7:
                self.assessment_responses["s7"] = self.nb_matcher_whodas.get_category(
                    user_input
                )
                return [
                    "Have you trouble with Washing your whole body?\n\n(None, Mild, Moderate, Severe, Extreme or cannot do)"]

            case 8:
                self.assessment_responses["s8"] = self.nb_matcher_whodas.get_category(user_input)
                return [
                    "Have you trouble with Getting dressed?\n\n(None, Mild, Moderate, Severe, Extreme or cannot do)"]

            case 9:
                self.assessment_responses["s9"] = self.nb_matcher_whodas.get_category(user_input)
                return [
                    "Have you trouble with Dealing with people you do not know?\n\n(None, Mild, Moderate, Severe, Extreme or cannot do)"]

            case 10:
                self.assessment_responses["s10"] = self.nb_matcher_whodas.get_category(user_input)
                return [
                    "Have you trouble with Maintaining a friendship?\n\n(None, Mild, Moderate, Severe, Extreme or cannot do)"]

            case 11:
                self.assessment_responses["s11"] = self.nb_matcher_whodas.get_category(user_input)
                return [
                    "Have you trouble with Your day-to-day work?\n\n(None, Mild, Moderate, Severe, Extreme or cannot do)"]

            case 12:
                self.assessment_responses["s12"] = self.nb_matcher_whodas.get_category(user_input)
                return ["Overall, in the past 30 days, how many days were these difficulties present?"]

            case 13:
                user_input = convert_to_integer(user_input)
                if user_input < 0 or user_input > 30:
                    self.update_whodas_assessment_step(telephone_number, -1)
                    return ["Sorry, this number is not between 0 and 30. Please try again"]

                self.assessment_responses["h1"] = user_input
                return [
                    "In the past 30 days, for how many days were you totally unable to carry out your usual activities or work because of any health condition?"]

            case 14:
                user_input = convert_to_integer(user_input)
                if user_input < 0 or user_input > 30:
                    self.update_whodas_assessment_step(telephone_number, -1)
                    return ["Sorry, this number is not between 0 and 30. Please try again"]

                self.assessment_responses["h2"] = user_input
                return ["In the past 30 days, not counting the days that you were totally unable, for how many days did you cut back or reduce your usual activities or work because of any health condition?"]

            case _:
                from config import sessions
                user_input = convert_to_integer(user_input)
                if user_input < 0 or user_input > 30:
                    self.update_whodas_assessment_step(telephone_number, -1)
                    return ["Sorry, this number is not between 0 and 30. Please try again"]

                self.assessment_responses["h3"] = user_input

                query_data = get_user_data(telephone_number)
                create_new_whodas_assessment(query_data.user_id, **self.assessment_responses)
                set_whodas_assessment_complete(query_data.telephone_number)
                sessions.new_session(telephone_number, query_data.name, query_data.user_id)

                self.delete_session(telephone_number)
                return ["This is a useful baseline. Thanks. We will check back in on these sometime soon.",
                        "So I am all yours now. Whats on your mind? How can I support you with academic stress?"]
